learned([]).
