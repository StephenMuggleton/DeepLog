modes([abcs04,cl,cl]).
